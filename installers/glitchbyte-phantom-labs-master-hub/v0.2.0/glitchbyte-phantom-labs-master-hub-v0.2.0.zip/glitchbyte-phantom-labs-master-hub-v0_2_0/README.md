# GLITCHBYTE PHANTOM LABS // MASTER HUB v0.2.0

**Rosie Phantom switchboard · Debian/Linux · Offline HTML + Python 3 standard library**

This independent upgrade does **not** overwrite the pinned v0.1.0 Master Hub or any sibling tools. It is a new `glitchbyte-phantom-labs-master-hub-v0_2_0/` directory.

## What is new

- Six distinctive logo-based operation switches, including HEXBAZAAR, PHANTOM SPINE, RIFTSEAL, reports, manuals, and art gallery.
- Separate actions: **Open installed page** (only when discovered), **Recipes**, **Manual**, **Copy easy command**.
- Three new pages: `manuals.html`, `gallery.html`, `public-front-door.html` (offline preview).
- Installed Page Finder: conservative scan of direct sibling tool folders and their `docs/*.html`, no recursive private files, no scanning of personal directories.
- All original seven HTML pages and tested example commands preserved. New switch commands are *copied*, not executed by the browser.
- The `public-front-door.html` page does not contain the live installed-page catalog or local private reports. It is a local preview, not a hosted site.

## Install

Place ZIP and SHA-256 in `~/Downloads`, then:

```bash
cd "$HOME/Downloads" &&
sha256sum -c glitchbyte-phantom-labs-master-hub-v0.2.0.sha256 &&
unzip -tq glitchbyte-phantom-labs-master-hub-v0.2.0.zip &&
test ! -e "$HOME/PhantomLabsLaunchers/glitchbyte-phantom-labs-master-hub-v0_2_0" &&
mkdir -p "$HOME/PhantomLabsLaunchers" &&
unzip -q glitchbyte-phantom-labs-master-hub-v0.2.0.zip -d "$HOME/PhantomLabsLaunchers" &&
bash "$HOME/PhantomLabsLaunchers/glitchbyte-phantom-labs-master-hub-v0_2_0/START_HUB.sh"
```

Reopen at any time:

```bash
bash "$HOME/PhantomLabsLaunchers/glitchbyte-phantom-labs-master-hub-v0_2_0/START_HUB.sh"
```

**Pinned shortcut:** Your old v0.1.0 pinned icon remains unchanged. When the new page opens, bookmark it with **Ctrl+D**. To switch an app-menu pin, optionally run `OPTIONAL_ADD_APP_MENU_SHORTCUT.sh` inside this v0.2.0 folder to create a *separate* new application entry, and pin that entry. No existing launchers are overwritten.

## Test and security model

```bash
python3 -B scripts/verify_hub.py
```

This verifies packaged asset checksums and internal links, not browser security or external live provider uptime. No external dependencies, scans, access to private databases, or automatic command execution from web buttons.

**Status:** The user's successful HEXBAZAAR v0.1.2-rc1 four-provider run on Debian 13 (Trixie) recorded 118 public observations on 2026-10-20. The new hub itself requires user visual verification in Firefox. Ubuntu not tested by user. Other tools' test labels are not inherited.
