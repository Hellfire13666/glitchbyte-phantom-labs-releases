#!/usr/bin/env python3
"""Offline verification for the Master Hub page pack."""
import hashlib,json,re,sys
from pathlib import Path
from html.parser import HTMLParser
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'MANIFEST.json').read_text())
for name,expect in manifest['files'].items():
 p=root/name
 assert p.is_file(), f'Missing: {name}'
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expect, f'Hash mismatch: {name}'
print('[PASS] Manifest:',len(manifest['files']),'original release files verified.')
# catalog.js is generated locally and intentionally excluded from manifest
for page in [root/'index.html',*(root/'recipes').glob('*.html')]:
 t=page.read_text()
 assert '<!DOCTYPE html>' in t and 'GLITCHBYTE' in t
 for href in re.findall(r'href="([^"]+)"',t):
  if href.startswith('#'):continue
  if href.startswith(('http:', 'https:','mailto:')):continue
  assert (page.parent/href.split('#',1)[0]).exists(),f'Broken local link in {page}: {href}'
print('[PASS] All static HTML pages and local links verified.')

for asset in (root/"assets").glob("tool-*.svg"):
 assert "<svg" in asset.read_text(), f"Not SVG: {asset}"
assert len(list((root/"assets").glob("tool-*.svg"))) == 6
print("[PASS] Six branded SVG tool badges verified.")
